# Lisan ud Dawat Review Agent

A small Python automation agent for the Lisan recorder/reviewer workflow at `https://lisan-frontend.vercel.app`.

## What it does

- Logs in with your stored reviewer credentials.
- Pulls the review task queue from the real backend API.
- Tries to clean each chunk:
  - applies your `ocr_replacements` mappings (fix OCR glitch characters),
  - removes non-Arabic script text (English, Hindi, Gujarati, etc.) when configured,
  - drops isolated punctuation.
- If `auto_submit` is `true`, it writes the cleaned text back, resolves any error flag, and marks the chunk as reviewed.
- If `auto_submit` is `false`, it previews the proposed correction without changing anything.
- Generates a live `status.html` dashboard and serves it on a local port.

## Files

- `agent.py` — the agent and dashboard server.
- `config.json` — your username/password and settings (not committed, ignored by Git).
- `config.example.json` — template.
- `fonts/` — Kanz al Marjaan fonts for the dashboard display.

## Run

```bash
python agent.py
```

Then open `status.html` in a browser, or visit `http://localhost:8080/status.html` (or `http://<your-machine-ip>:8080/status.html` from a phone on the same network).

On Windows, run in the background without a console window:

```powershell
pythonw agent.py
```

## Important settings

Edit `config.json`:

```json
{
  "username": "reviewer_01",
  "password": "pass_reviewer_01_lisan",
  "auto_submit": false,
  "max_chunks": 100,
  "min_words": 200,
  "ocr_replacements": {
    "example_wrong_char": "correct_char"
  },
  "urdu_to_lisan": {}
}
```

- `auto_submit`: keep `false` until you are happy with the preview output; set to `true` to actually update, resolve flags, and mark reviewed.
- `min_words`: chunks whose corrected text has fewer words than this are skipped.
- `ocr_replacements`: map wrong characters/strings to correct ones. Add entries from your OCR-glitch PDF.
- `urdu_to_lisan`: optional whole-word dictionary to replace common Urdu words with Lisan equivalents.

## Limitations and reality checks

- This is a **script/dashboard** that runs on a computer, not a native Android overlay app. A true Android overlay/background app would need the Android SDK and cannot be built or packaged on this Windows environment.
- The agent cannot guarantee “0% mistakes” or “200% accuracy.” It applies the rules *you* give it. High-quality Lisan grammar/sense checking requires a trained model or human reviewer.
- Real speed depends on the Render backend latency. Three worker threads are used, but the API often takes 2–5 seconds per call, so “80 chunks in 5 minutes” is unlikely without much higher concurrency and a faster backend.
- The chunk size requirement (≥200 words) is enforced as a guard (`min_words`), but many chunks in the current queue are shorter, so they will be skipped unless you lower the threshold.

## Live dashboard

The dashboard is written to `status.html` and auto-refreshes every 5 seconds. The `agent.py` process also starts a tiny HTTP server on port 8080 so you can view it from a browser on the same network.
