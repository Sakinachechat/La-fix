#!/usr/bin/env python3
"""
Lisan ud Dawat Review Agent
A background automation helper for the Lisan recorder/reviewer workflow.
"""
import json
import logging
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

# --- Constants ---
PROJECT_DIR = Path(__file__).parent.resolve()
CONFIG_PATH = PROJECT_DIR / "config.json"
STATUS_PATH = PROJECT_DIR / "status.html"
LOG_PATH = PROJECT_DIR / "agent.log"

# Base allowed characters: Arabic/Lisan script blocks, digits, punctuation, whitespace
BASE_ALLOWED_CHARS = (
    r"\u0600-\u06FF"          # Arabic
    r"\u0750-\u077F"          # Arabic Supplement
    r"\u08A0-\u08FF"          # Arabic Extended-A
    r"\u0870-\u089F"          # Arabic Extended-B
    r"\uFB50-\uFDFF"          # Arabic Presentation Forms-A
    r"\uFE70-\uFEFF"          # Arabic Presentation Forms-B
    r"\s"                     # whitespace
    r"0-9\u0660-\u0669\u06F0-\u06F9"  # digits
    r".,;:!?()\[\]{}\"'‘’“”\-–—…/\\«»؟،؛"  # punctuation
    r"%‰"                     # percent
    r"\u200C\u200D"            # ZWNJ / ZWJ
)
ARABIC_OR_DIGIT_RE = re.compile(
    r"[0-9"
    r"\u0660-\u0669\u06F0-\u06F9"
    r"\u0600-\u06FF"
    r"\u0750-\u077F"
    r"\u08A0-\u08FF"
    r"\u0870-\u089F"
    r"\uFB50-\uFDFF"
    r"\uFE70-\uFEFF]",
    re.UNICODE,
)
WHITESPACE_REGEX = re.compile(r"\s+", re.UNICODE)


# --- Logging ---
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_PATH, encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)


class Status:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.processed = 0
        self.skipped = 0
        self.errors = 0
        self.current_task = None
        self.current_action = "Idle"
        self.log_lines = []
        self.original_preview = ""
        self.corrected_preview = ""

    def add_log(self, line: str):
        with self.lock:
            self.log_lines.append(f"{datetime.now().isoformat(timespec='seconds')}  {line}")
            self.log_lines = self.log_lines[-100:]
        logging.info(line)

    def update(
        self,
        action: str = None,
        current_task: dict = None,
        original_preview: str = None,
        corrected_preview: str = None,
        processed: int = None,
        skipped: int = None,
        errors: int = None,
    ):
        with self.lock:
            if action is not None:
                self.current_action = action
            if current_task is not None:
                self.current_task = current_task
            if original_preview is not None:
                self.original_preview = original_preview
            if corrected_preview is not None:
                self.corrected_preview = corrected_preview
            if processed is not None:
                self.processed = processed
            if skipped is not None:
                self.skipped = skipped
            if errors is not None:
                self.errors = errors

    def render_dashboard(self):
        with self.lock:
            task_name = (self.current_task or {}).get("name", "—")
            task_id = (self.current_task or {}).get("id", "—")
            original = self.original_preview or ""
            corrected = self.corrected_preview or ""
            log_html = "\n".join(f"<li>{self._escape(l)}</li>" for l in reversed(self.log_lines))
            return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="5">
<title>Lisan Review Agent</title>
<style>
  @font-face {{ font-family: 'Kanz'; src: url('fonts/Kanz-al-Marjaan.ttf') format('truetype'); }}
  @font-face {{ font-family: 'Kanz2'; src: url('fonts/Al-Kanz_for_Windows.ttf') format('truetype'); }}
  body {{ font-family: 'Kanz', 'Kanz2', 'Segoe UI', sans-serif; direction: rtl; padding: 1rem; background: #f7f7f7; color: #222; }}
  h1 {{ color: #b8860b; }}
  .card {{ background: #fff; border-radius: 12px; padding: 1rem; margin-bottom: 1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }}
  .meta {{ color: #666; font-size: 0.9rem; margin-bottom: 0.5rem; }}
  .textbox {{ background: #f0f0f0; padding: 0.75rem; border-radius: 8px; white-space: pre-wrap; word-wrap: break-word; font-family: 'Kanz', 'Kanz2', sans-serif; font-size: 1.15rem; }}
  .stats {{ display: flex; gap: 1rem; flex-wrap: wrap; }}
  .stat {{ min-width: 120px; }}
  .stat b {{ display: block; font-size: 1.5rem; color: #b8860b; }}
  ul {{ list-style: none; padding: 0; max-height: 300px; overflow-y: auto; }}
  li {{ padding: 0.4rem 0; border-bottom: 1px solid #eee; font-family: monospace; font-size: 0.85rem; }}
  .running {{ color: green; }} .stopped {{ color: red; }}
</style>
</head>
<body>
<h1>Lisan ud Dawat Review Agent</h1>
<p>Status: <strong class="{'running' if self.running else 'stopped'}">{'Running' if self.running else 'Stopped'}</strong> | Action: {self._escape(self.current_action)}</p>
<div class="card stats">
  <div class="stat"><b>{self.processed}</b> processed</div>
  <div class="stat"><b>{self.skipped}</b> skipped</div>
  <div class="stat"><b>{self.errors}</b> errors</div>
</div>
<div class="card">
  <div class="meta">Current task: {self._escape(str(task_id))} — {self._escape(str(task_name))}</div>
  <h3>Original text</h3>
  <div class="textbox">{self._escape(original)}</div>
  <h3>Corrected text</h3>
  <div class="textbox">{self._escape(corrected)}</div>
</div>
<div class="card">
  <h3>Recent log</h3>
  <ul>{log_html}</ul>
</div>
</body>
</html>"""

    @staticmethod
    def _escape(text: str) -> str:
        return (
            text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
        )


STATUS = Status()


# --- Config ---
def load_config():
    if not CONFIG_PATH.exists():
        raise FileNotFoundError(f"{CONFIG_PATH} not found. Create it from the template.")
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save_config(cfg: dict):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


# --- API client ---
class LisanClient:
    def __init__(self, cfg: dict):
        self.base_url = cfg["backend_url"].rstrip("/")
        self.username = cfg["username"]
        self.password = cfg["password"]
        self._token = None

    def _request(self, method: str, path: str, data: dict = None):
        url = self.base_url + path
        body = json.dumps(data, ensure_ascii=False).encode("utf-8") if data is not None else None
        headers = {"Authorization": f"Bearer {self._token}"} if self._token else {}
        if body is not None:
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=body, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                return resp.status, resp.read().decode("utf-8")
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8")

    def login(self):
        data = f"username={urllib.parse.quote(self.username)}&password={urllib.parse.quote(self.password)}"
        req = urllib.request.Request(
            self.base_url + "/auth/login",
            data=data.encode("utf-8"),
            method="POST",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                result = json.loads(resp.read().decode("utf-8"))
                self._token = result["access_token"]
                return True
        except urllib.error.HTTPError as e:
            STATUS.add_log(f"Login failed: HTTP {e.code} {e.read().decode('utf-8')}")
            return False

    def get_me(self):
        return self._request("GET", "/auth/me")

    def list_review_tasks(self, limit=100, offset=0):
        code, body = self._request("GET", f"/texts/review/list?limit={limit}&offset={offset}")
        if code == 200:
            return json.loads(body)
        STATUS.add_log(f"List review tasks failed: HTTP {code} {body[:200]}")
        return []

    def update_task(self, task_id: int, content: str):
        return self._request("PUT", f"/texts/update/{task_id}", {"content": content})

    def resolve_flag(self, task_id: int):
        return self._request("POST", f"/texts/error-flag/resolve/{task_id}")

    def mark_reviewed(self, task_id: int):
        return self._request("POST", f"/texts/mark-reviewed/{task_id}")




# --- Text correction ---
def apply_replacements(text: str, replacements: dict) -> str:
    # Longest keys first to avoid partial replacements
    for key, value in sorted(replacements.items(), key=lambda kv: len(kv[0]), reverse=True):
        text = re.sub(re.escape(key), lambda m: value, text)
    return text


def script_filter(text: str, remove_latin=True, remove_indic=True, remove_other=True) -> str:
    """Remove characters from disallowed scripts and collapse whitespace."""
    allowed = BASE_ALLOWED_CHARS
    if not remove_latin:
        allowed += r"A-Za-z"
    if not remove_indic:
        allowed += r"\u0900-\u097F\u0980-\u09FF\u0A00-\u0A7F\u0A80-\u0AFF\u0B00-\u0B7F\u0B80-\u0BFF\u0C00-\u0C7F\u0C80-\u0CFF\u0D00-\u0D7F\u0D80-\u0DFF\u0E00-\u0E7F\u0E80-\u0EFF\u0F00-\u0FFF\u1000-\u109F\u1100-\u11FF\u1780-\u17FF\u1900-\u194F"
    if not remove_other:
        # allow everything else that is not already handled
        allowed += r"\u0000-\uFFFF"

    disallowed = re.compile(f"[^{allowed}]+", re.UNICODE)
    text = disallowed.sub(" ", text)
    text = WHITESPACE_REGEX.sub(" ", text).strip()
    # Drop tokens that are only punctuation/stray symbols; keep Arabic/digit-bearing tokens
    tokens = text.split()
    meaningful = [t for t in tokens if ARABIC_OR_DIGIT_RE.search(t)]
    return " ".join(meaningful)


def correct_text(text: str, cfg: dict) -> str:
    # 1. OCR character replacements
    text = apply_replacements(text, cfg.get("ocr_replacements", {}))
    # 2. Whole-word Urdu -> Lisan replacements
    urdu_map = cfg.get("urdu_to_lisan", {})
    if urdu_map:
        words = text.split()
        words = [urdu_map.get(w, w) for w in words]
        text = " ".join(words)
    # 3. Strip disallowed scripts (English, Hindi/Gujarati, etc.)
    text = script_filter(
        text,
        remove_latin=cfg.get("remove_latin", True),
        remove_indic=cfg.get("remove_indic", True),
        remove_other=cfg.get("remove_other_scripts", True),
    )
    return text


def word_count(text: str) -> int:
    return len(text.split())


# --- Dashboard server ---
class DashboardHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, directory=None, **kwargs):
        super().__init__(*args, directory=directory, **kwargs)

    def log_message(self, fmt, *args):
        pass


def start_dashboard(host: str, port: int):
    server = ThreadingHTTPServer((host, port), lambda *args, **kwargs: DashboardHandler(*args, directory=str(PROJECT_DIR), **kwargs))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    STATUS.add_log(f"Dashboard running at http://{host}:{port}")


def refresh_dashboard():
    try:
        STATUS.render_dashboard()
        STATUS_PATH.write_text(STATUS.render_dashboard(), encoding="utf-8")
    except Exception as e:
        logging.error(f"Dashboard render error: {e}")


# --- Task processing ---
def process_task(client: LisanClient, cfg: dict, task: dict):
    task_id = task["id"]
    task_name = task.get("name", f"#{task_id}")
    original = task.get("content", "")

    STATUS.update(
        action=f"Correcting {task_name}",
        current_task=task,
        original_preview=original[:600],
        corrected_preview="",
    )
    refresh_dashboard()

    corrected = correct_text(original, cfg)
    before_wc = word_count(original)
    after_wc = word_count(corrected)

    STATUS.update(corrected_preview=corrected[:600])
    refresh_dashboard()

    STATUS.add_log(f"Task {task_name}: {before_wc} -> {after_wc} words")

    if not corrected.strip():
        STATUS.add_log(f"Task {task_name} skipped: correction produced empty text")
        STATUS.update(skipped=STATUS.skipped + 1)
        refresh_dashboard()
        return False

    min_words = cfg.get("min_words", 200)
    if after_wc < min_words:
        STATUS.add_log(
            f"Task {task_name} skipped: corrected length ({after_wc} words) below min_words ({min_words})"
        )
        STATUS.update(skipped=STATUS.skipped + 1)
        refresh_dashboard()
        return False

    if not cfg.get("auto_submit", False):
        STATUS.add_log(f"Task {task_name} corrected (preview only — auto_submit is false)")
        STATUS.update(skipped=STATUS.skipped + 1)
        refresh_dashboard()
        return False

    # Update content
    STATUS.update(action=f"Saving {task_name}")
    refresh_dashboard()
    code, body = client.update_task(task_id, corrected)
    if code != 200:
        STATUS.add_log(f"Update failed for {task_name}: HTTP {code} {body[:200]}")
        STATUS.update(errors=STATUS.errors + 1)
        refresh_dashboard()
        return False

    # Resolve flag if present
    if task.get("error_flag_status") == "pending":
        STATUS.update(action=f"Resolving flag {task_name}")
        refresh_dashboard()
        code, body = client.resolve_flag(task_id)
        if code != 200:
            STATUS.add_log(f"Resolve flag failed for {task_name}: HTTP {code} {body[:200]}")
            STATUS.update(errors=STATUS.errors + 1)
            refresh_dashboard()
            return False

    # Mark reviewed
    STATUS.update(action=f"Marking reviewed {task_name}")
    refresh_dashboard()
    code, body = client.mark_reviewed(task_id)
    if code != 200:
        STATUS.add_log(f"Mark reviewed failed for {task_name}: HTTP {code} {body[:200]}")
        STATUS.update(errors=STATUS.errors + 1)
        refresh_dashboard()
        return False

    STATUS.add_log(f"Task {task_name} completed")
    STATUS.update(processed=STATUS.processed + 1)
    refresh_dashboard()
    return True


def run(cfg: dict):
    STATUS.running = True
    client = LisanClient(cfg)
    if not client.login():
        STATUS.running = False
        refresh_dashboard()
        return

    code, body = client.get_me()
    if code != 200:
        STATUS.add_log(f"/auth/me failed: HTTP {code} {body[:200]}")
        STATUS.running = False
        refresh_dashboard()
        return
    try:
        me = json.loads(body)
        STATUS.add_log(f"Logged in as {me.get('username')} / role {me.get('role')}")
    except Exception:
        STATUS.add_log("Logged in")

    max_chunks = cfg.get("max_chunks", 100)
    workers = cfg.get("workers", 3)

    def total_handled():
        return STATUS.processed + STATUS.skipped + STATUS.errors

    while STATUS.running and total_handled() < max_chunks:
        remaining = max_chunks - total_handled()
        # Fetch fresh first page each iteration because reviewed tasks disappear
        tasks = client.list_review_tasks(limit=min(100, remaining + workers))
        if not tasks:
            STATUS.add_log("No pending review tasks. Waiting...")
            refresh_dashboard()
            time.sleep(cfg.get("poll_interval_seconds", 30))
            continue

        # Order: flagged first, then unflagged, then rejected/resolved
        def sort_key(t):
            fs = t.get("error_flag_status")
            if fs == "pending":
                return 0
            if fs is None:
                return 1
            return 2

        tasks.sort(key=sort_key)

        # Process a batch up to workers*2
        batch_size = min(workers * 2, remaining, len(tasks))
        batch = tasks[:batch_size]

        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(process_task, client, cfg, t): t for t in batch}
            for future in as_completed(futures):
                task = futures[future]
                try:
                    future.result()
                except Exception as exc:
                    STATUS.add_log(f"Exception on {task.get('name')}: {exc}")
                    STATUS.update(errors=STATUS.errors + 1)
                    refresh_dashboard()

    STATUS.add_log("Run finished")
    STATUS.running = False
    refresh_dashboard()


def main():
    cfg = load_config()
    # Ensure config is up-to-date (new fields added by us)
    save_config(cfg)

    host = cfg.get("dashboard_host", "127.0.0.1")
    port = cfg.get("dashboard_port", 8080)
    start_dashboard(host, port)

    if cfg.get("auto_start", False):
        thread = threading.Thread(target=run, args=(cfg,), daemon=True)
        thread.start()
        STATUS.add_log("Agent started in background")
    else:
        STATUS.add_log("Agent ready (auto_start is false)")

    refresh_dashboard()

    # Keep main thread alive; dashboard runs in daemon thread
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        STATUS.running = False
        STATUS.add_log("Agent stopped")
        refresh_dashboard()
        sys.exit(0)


if __name__ == "__main__":
    main()
